.. Python Audio Tools documentation master file, created by
   sphinx-quickstart on Wed Mar 17 10:20:37 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Python Audio Tools's documentation!
==============================================

Contents:

.. toctree::
   :maxdepth: 2

   audiotools.rst
   audiotools_pcm.rst
   audiotools_bitstream.rst
   audiotools_pcmconverter.rst
   audiotools_replaygain.rst
   audiotools_cdio.rst
   audiotools_freedb.rst
   audiotools_musicbrainz.rst
   audiotools_accuraterip.rst
   audiotools_cue.rst
   audiotools_toc.rst
   audiotools_ui.rst
   audiotools_player.rst
   metadata.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
